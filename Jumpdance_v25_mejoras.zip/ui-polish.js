(() => {
  'use strict';

  let viewer = null;
  let viewerImage = null;
  let viewerTitle = null;
  let viewerCount = null;
  let viewerDownload = null;
  let currentImages = [];
  let currentIndex = 0;
  let lastFocused = null;
  let touchStartX = 0;

  function createViewer() {
    if (viewer) return;

    viewer = document.createElement('div');
    viewer.className = 'jd-photo-viewer';
    viewer.setAttribute('role', 'dialog');
    viewer.setAttribute('aria-modal', 'true');
    viewer.setAttribute('aria-label', 'Visor de fotos');
    viewer.innerHTML = `
      <div class="jd-photo-toolbar">
        <button class="jd-photo-btn" type="button" data-jd-close aria-label="Cerrar foto">✕ Cerrar</button>
        <div class="jd-photo-title" data-jd-title>Foto</div>
        <a class="jd-photo-btn primary" data-jd-download href="#" download>⬇ Descargar</a>
      </div>
      <div class="jd-photo-stage" data-jd-stage>
        <button class="jd-photo-nav jd-photo-prev" type="button" data-jd-prev aria-label="Foto anterior">‹</button>
        <img data-jd-image alt="Foto de Jumpdance">
        <button class="jd-photo-nav jd-photo-next" type="button" data-jd-next aria-label="Foto siguiente">›</button>
      </div>
      <div class="jd-photo-footer">
        <span class="jd-photo-count" data-jd-count></span>
      </div>
    `;

    document.body.appendChild(viewer);

    viewerImage = viewer.querySelector('[data-jd-image]');
    viewerTitle = viewer.querySelector('[data-jd-title]');
    viewerCount = viewer.querySelector('[data-jd-count]');
    viewerDownload = viewer.querySelector('[data-jd-download]');

    viewer.querySelector('[data-jd-close]').addEventListener('click', closeViewer);
    viewer.querySelector('[data-jd-prev]').addEventListener('click', () => movePhoto(-1));
    viewer.querySelector('[data-jd-next]').addEventListener('click', () => movePhoto(1));

    viewer.addEventListener('click', (event) => {
      if (event.target === viewer || event.target.matches('[data-jd-stage]')) {
        closeViewer();
      }
    });

    const stage = viewer.querySelector('[data-jd-stage]');
    stage.addEventListener('touchstart', (event) => {
      touchStartX = event.changedTouches?.[0]?.clientX || 0;
    }, { passive: true });

    stage.addEventListener('touchend', (event) => {
      const endX = event.changedTouches?.[0]?.clientX || 0;
      const delta = endX - touchStartX;
      if (Math.abs(delta) < 55) return;
      movePhoto(delta < 0 ? 1 : -1);
    }, { passive: true });
  }

  function galleryImages() {
    return Array.from(document.querySelectorAll('.mediaGrid img'))
      .filter(img => img.offsetParent !== null && !img.closest('.jd-photo-viewer'));
  }

  function cleanName(img) {
    const src = img.currentSrc || img.src || '';
    try {
      const pathname = new URL(src, location.href).pathname;
      return decodeURIComponent(pathname.split('/').pop() || 'Foto Jumpdance');
    } catch {
      return img.alt || 'Foto Jumpdance';
    }
  }

  function renderPhoto() {
    if (!currentImages.length) return;

    const img = currentImages[currentIndex];
    const src = img.currentSrc || img.src;
    viewerImage.src = src;
    viewerImage.alt = img.alt || 'Foto de Jumpdance';
    viewerTitle.textContent = cleanName(img);
    viewerCount.textContent = `${currentIndex + 1} de ${currentImages.length}`;
    viewerDownload.href = src;
    viewerDownload.setAttribute('download', cleanName(img));

    const hasMany = currentImages.length > 1;
    viewer.querySelector('[data-jd-prev]').style.visibility = hasMany ? 'visible' : 'hidden';
    viewer.querySelector('[data-jd-next]').style.visibility = hasMany ? 'visible' : 'hidden';
  }

  function openViewer(img) {
    createViewer();
    currentImages = galleryImages();
    currentIndex = Math.max(0, currentImages.indexOf(img));
    lastFocused = document.activeElement;

    renderPhoto();
    viewer.classList.add('is-open');
    document.body.classList.add('jd-modal-open');
    viewer.querySelector('[data-jd-close]').focus({ preventScroll: true });
  }

  function closeViewer() {
    if (!viewer) return;
    viewer.classList.remove('is-open');
    document.body.classList.remove('jd-modal-open');
    if (lastFocused && typeof lastFocused.focus === 'function') {
      lastFocused.focus({ preventScroll: true });
    }
  }

  function movePhoto(direction) {
    if (!currentImages.length) return;
    currentIndex = (currentIndex + direction + currentImages.length) % currentImages.length;
    renderPhoto();
  }

  document.addEventListener('click', (event) => {
    const img = event.target.closest?.('.mediaGrid img');
    if (!img || img.closest('.jd-photo-viewer')) return;

    event.preventDefault();
    event.stopImmediatePropagation();
    openViewer(img);
  }, true);

  document.addEventListener('keydown', (event) => {
    if (!viewer?.classList.contains('is-open')) return;

    if (event.key === 'Escape') closeViewer();
    if (event.key === 'ArrowLeft') movePhoto(-1);
    if (event.key === 'ArrowRight') movePhoto(1);
  });

  // Evita el zoom accidental de la interfaz en navegadores iOS antiguos.
  ['gesturestart', 'gesturechange', 'gestureend'].forEach(name => {
    document.addEventListener(name, event => {
      if (!event.target.closest?.('.jd-photo-viewer')) event.preventDefault();
    }, { passive: false });
  });

  function adminMapping(tabs) {
    return Array.from(tabs.querySelectorAll('button')).map(button => {
      const inline = button.getAttribute('onclick') || '';
      const match = inline.match(/getElementById\(['"]([^'"]+)['"]\)/);
      return match ? { button, id: match[1] } : null;
    }).filter(Boolean);
  }

  function activateAdminTab(items, id) {
    if (!items.length) return;

    const selected = items.find(item => item.id === id) || items[0];

    items.forEach(({ button, id: sectionId }) => {
      const section = document.getElementById(sectionId);
      if (!section) return;

      section.classList.add('jd-admin-panel');
      section.hidden = sectionId !== selected.id;
      button.classList.toggle('jd-admin-tab-active', sectionId === selected.id);
      button.setAttribute('aria-selected', sectionId === selected.id ? 'true' : 'false');
    });

    sessionStorage.setItem('jumpdanceAdminTab', selected.id);
  }

  function enhanceAdmin() {
    const tabs = document.querySelector('.adminTabs');
    if (!tabs || tabs.dataset.jdEnhanced === '1') return;

    const items = adminMapping(tabs);
    if (!items.length) return;

    tabs.dataset.jdEnhanced = '1';
    tabs.setAttribute('role', 'tablist');

    const intro = document.createElement('div');
    intro.className = 'jd-admin-intro';
    intro.innerHTML = '<strong>Administración organizada</strong>Elegí una sección. Para revisar quién se inscribió y quién envió música, entrá en “Música e inscripciones”.';
    tabs.before(intro);

    items.forEach(({ button, id }) => {
      const oldText = button.textContent.trim();
      if (/inscripciones/i.test(oldText)) button.textContent = '🎵 Música e inscripciones';
      else if (/multimedia/i.test(oldText)) button.textContent = '📸 Fotos y videos';
      else if (/portada/i.test(oldText)) button.textContent = '🖼️ Portada';
      else if (/sponsors/i.test(oldText)) button.textContent = '⭐ Sponsors';
      else if (/resultados/i.test(oldText)) button.textContent = '🏆 Resultados';
      else if (/novedades/i.test(oldText)) button.textContent = '📢 Novedades';
      else if (/publicaciones/i.test(oldText)) button.textContent = '📝 Publicaciones';
      else if (/mensajes/i.test(oldText)) button.textContent = '💬 Mensajes';

      button.removeAttribute('onclick');
      button.setAttribute('role', 'tab');
      button.addEventListener('click', () => {
        activateAdminTab(items, id);
        window.scrollTo({ top: Math.max(0, tabs.offsetTop - 82), behavior: 'smooth' });
      });
    });

    const stored = sessionStorage.getItem('jumpdanceAdminTab');
    const preferred = items.some(x => x.id === stored)
      ? stored
      : (items.find(x => /ins/i.test(x.id))?.id || items[0].id);

    activateAdminTab(items, preferred);
  }

  const observer = new MutationObserver(() => {
    window.requestAnimationFrame(enhanceAdmin);
  });

  observer.observe(document.getElementById('app') || document.body, {
    childList: true,
    subtree: true
  });

  window.addEventListener('hashchange', () => {
    window.requestAnimationFrame(enhanceAdmin);
  });

  window.addEventListener('load', () => {
    createViewer();
    enhanceAdmin();
  });
})();
