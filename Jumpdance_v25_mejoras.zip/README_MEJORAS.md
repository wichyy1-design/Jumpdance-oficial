# Jumpdance 2026 — mejoras v25

Este paquete agrega una capa visual sin modificar la lógica de datos existente.

## Cambios incluidos
- La pantalla principal deja de poder ampliarse/achicarse accidentalmente.
- Las fotos siguen en grilla; al tocar una se abre un visor sobre la misma sección.
- Visor con Cerrar, Descargar, anterior/siguiente, teclado y deslizamiento.
- Los videos conservan sus controles y pantalla completa.
- Mejor estabilidad horizontal y responsive.
- Microtransiciones suaves y retoques de aspecto deportivo/profesional.
- Panel Administrador ordenado por pestañas: se ve una sección por vez.
- “Inscripciones” pasa a mostrarse como “Música e inscripciones” para encontrar rápido quién envió material.
- Se actualiza el service worker a caché v25 para que los cambios lleguen a los celulares.

## Archivos
- index.html (reemplaza el actual)
- service-worker.js (reemplaza el actual)
- ui-polish.css (nuevo)
- ui-polish.js (nuevo)

## Importante sobre “Agregar usuarios”
No se incluye una falsa pantalla de usuarios. Para crear usuarios de forma segura hay que hacerlo desde un backend/Edge Function con permisos de administración de Supabase; nunca se debe poner una service-role key dentro de la app. Esa parte requiere acceso de escritura al proyecto Supabase Jumpdance2026.

## Publicación
Subir los cuatro archivos a la raíz del repositorio. Cloudflare/GitHub debería desplegar la versión nueva según el flujo ya existente.
